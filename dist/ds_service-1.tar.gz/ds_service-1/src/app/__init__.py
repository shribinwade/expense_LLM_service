import os
import sys
import time
import logging

from kafka import KafkaProducer
from kafka.errors import NoBrokersAvailable

print("Python used:", sys.executable)
from flask import Flask, json
from flask import request, jsonify
from app.service.messageService import MessageService

app = Flask(__name__)
app.config.from_pyfile('config.py')

messageService = MessageService()

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

_producer = None

def get_producer():
    """Lazily create the Kafka producer on first use, with retry.
    Never blocks app startup, never crashes the process."""
    global _producer
    if _producer is not None:
        return _producer

    kafka_host = os.getenv('KAFKA_HOST')
    kafka_port = os.getenv('KAFKA_PORT')
    bootstrap = f"{kafka_host}:{kafka_port}"

    retries = 5
    delay = 2
    for attempt in range(1, retries + 1):
        try:
            _producer = KafkaProducer(
                bootstrap_servers=bootstrap,
                value_serializer=lambda v: json.dumps(v).encode('utf-8'),
                request_timeout_ms=5000,
            )
            logger.info("Connected to Kafka at %s", bootstrap)
            return _producer
        except NoBrokersAvailable:
            logger.warning(
                "Kafka not reachable at %s (attempt %d/%d)",
                bootstrap, attempt, retries
            )
            time.sleep(delay)

    logger.error("Could not connect to Kafka after %d attempts", retries)
    return None


@app.route('/v1/ds/message', methods=['POST'])
def handle_message():
    message = request.json.get('message')
    result = messageService.process_message(message)

    if isinstance(result, list):
        return jsonify([item.dict() for item in result])

    elif result is not None and hasattr(result, "dict"):
        serialized_result = jsonify(result.dict())

        producer = get_producer()
        if producer is not None:
            try:
                producer.send('expense_service', value=result.dict())
            except Exception:
                logger.exception("Failed to publish to Kafka")
                # decide: fail the request, or degrade gracefully
        else:
            logger.error("Kafka producer unavailable; message not published")

        return serialized_result

    else:
        return jsonify(result)


@app.route('/', methods=['GET'])
def handle_get():
    return 'hello world'


@app.route('/v1/ds/health', methods=['GET'])
def health_check():
    return 'OK'


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8010, debug=False, use_reloader=False)